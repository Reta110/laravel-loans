<!-- Id Field -->
<div class="col-md-1 form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $activity->id !!}</p>
</div>

<!-- Amount Field -->
<div class="col-md-2 form-group">
    {!! Form::label('amount', 'Amount:') !!}
    <p>{!! $activity->amount !!}</p>
</div>

<!-- Earnings Field -->
<div class="col-md-2 form-group">
    {!! Form::label('earnings', 'Earnings:') !!}
    <p>{!! $activity->earnings !!}</p>
</div>

<!-- Due Field -->
<div class="col-md-1 form-group">
    {!! Form::label('due', 'Due:') !!}
    <p>{!! $activity->due !!}</p>
</div>

<!-- Date Field -->
<div class="col-md-2 form-group">
    {!! Form::label('date', 'Date:') !!}
    <p>{!! $activity->date !!}</p>
</div>

<!-- Activity Type Id Field -->
<div class="col-md-2 form-group">
    {!! Form::label('activity_type_id', 'Activity Type:') !!}
    <p>{!! $activity->activityType->name !!}</p>
</div>

<!-- Name Field -->
<div class="col-md-2 form-group">
    {!! Form::label('name', 'Observation:') !!}
    <p>{!! $activity->name !!}</p>
</div>

@can('advanced')
    <!-- Client Percents Field -->
    <div class="col-md-12 form-group">
        {!! Form::label('client_percents', 'Client Percents:') !!}
        <ul>
            @foreach(json_decode($activity->client_earnings) as $client)
                <li>{{ $client->name }}: {{ $client->earning_amount }} ({{ $client->percent }}%)</li>
            @endforeach
        </ul>
    </div>
@endcan
