<!-- Loan id Type Id Field -->
<div class="form-group col-sm-6">
    {!! Form::label('loan_id', 'Loan:') !!}
    <select class="form-control" id="loan_id" name="loan_id">
        @foreach($loans as $loan)

            <option value="{{$loan->id}}"  data-nextdue="{{count($loan->activities) + 1 }}" data-pending="{{$loan->amount - $loan->activities->sum('amount')}}"
                    @isset ($activity) @if ($activity->loan_id == $loan->id) selected @endif @endisset>
                #{{$loan->id}} - {{$loan->user->name}} - Amount: {{$loan->amount}} - Pending: ({{$loan->amount - $loan->activities->sum('amount')}})
            </option>
        @endforeach
    </select>
    {{--- Form::select('loan_id', $loans,  null, ['class' => 'form-control']) ---}}
</div>

<!-- Name Field -->
<div class="form-group col-sm-6">
    {!! Form::label('name', 'Total amount:') !!}
    {!! Form::text('tot_amount', null, ['class' => 'form-control', 'id' => 'aux_amount']) !!}
</div>

<!-- Amount Field -->
<div class="form-group col-sm-6">
    {!! Form::label('amount', 'Amount:') !!}
    {!! Form::number('amount', null, ['class' => 'form-control', 'id' => 'activyty_amount']) !!}
</div>

<!-- Earnings Field -->
<div class="form-group col-sm-6">
    {!! Form::label('earnings', 'Interest:') !!}
    {!! Form::number('earnings', null, ['class' => 'form-control', 'id' => 'activyty_earnings']) !!}
</div>

{{--- Client Earnings Field -->
<div class="form-group col-sm-12 col-lg-12">
    {!! Form::label('client_earnings', 'Client Earnings:') !!}
    {!! Form::textarea('client_earnings', null, ['class' => 'form-control']) !!}
</div>
---}}
<!-- Due Field -->
<div class="form-group col-sm-6">
    {!! Form::label('due', 'Due:') !!}
    {!! Form::number('due', null, ['class' => 'form-control', 'id' => 'next-due']) !!}
</div>

<!-- Date Field -->
<div class="form-group col-sm-6">
    {!! Form::label('date', 'Date:') !!}
    {!! Form::date('date', null, ['class' => 'form-control','id'=>'date']) !!}
</div>

@section('scripts')
    <script type="text/javascript">
        $('#date').datetimepicker({
            format: 'YYYY-MM-DD',
            useCurrent: true,
        })

        $('#loan_id').on('change', function () {

            var nextdue = $("#loan_id option:selected").data('nextdue');
            $('#next-due').val(nextdue);

        });

        $('#aux_amount').on('change', function () {

            var pending = $("#loan_id option:selected").data('pending');
            let total = $(this).val();
            let earnings = (2 * pending) / 100;
            let amount = total - earnings;

            $("#activyty_amount").val(amount);
            $("#activyty_earnings").val(earnings);

        });
    </script>
@endsection

<!-- Activity Type Id Field -->
<div class="form-group col-sm-6">
    {!! Form::label('activity_type_id', 'Activity Type:') !!}
    {!! Form::select('activity_type_id', $activities, null, ['class' => 'form-control']) !!}
</div>

<!-- Name Field -->
<div class="form-group col-sm-6">
    {!! Form::label('name', 'Observation:') !!}
    {!! Form::text('name', null, ['class' => 'form-control']) !!}
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
    <a href="{!! route('activities.index') !!}" class="btn btn-default">Cancel</a>
</div>
