<!-- Loan id Type Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('loan_id', 'Loan:'); ?>

    <select class="form-control" id="loan_id" name="loan_id">
        <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($loan->id); ?>"  data-nextdue="<?php echo e(count($loan->activities) + 1); ?>" data-pending="<?php echo e($loan->amount - $loan->activities->sum('amount')); ?>"
                    <?php if(isset($activity)): ?> <?php if($activity->loan_id == $loan->id): ?> selected <?php endif; ?> <?php endif; ?>>
                #<?php echo e($loan->id); ?> - <?php echo e($loan->user->name); ?> - Amount: <?php echo e($loan->amount); ?> - Pending: (<?php echo e($loan->amount - $loan->activities->sum('amount')); ?>)
            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    
</div>

<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Total amount:'); ?>

    <?php echo Form::text('tot_amount', null, ['class' => 'form-control', 'id' => 'aux_amount']); ?>

</div>

<!-- Amount Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('amount', 'Amount:'); ?>

    <?php echo Form::number('amount', null, ['class' => 'form-control', 'id' => 'activyty_amount']); ?>

</div>

<!-- Earnings Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('earnings', 'Interest:'); ?>

    <?php echo Form::number('earnings', null, ['class' => 'form-control', 'id' => 'activyty_earnings']); ?>

</div>


<!-- Due Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('due', 'Due:'); ?>

    <?php echo Form::number('due', null, ['class' => 'form-control', 'id' => 'next-due']); ?>

</div>

<!-- Date Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('date', 'Date:'); ?>

    <?php echo Form::date('date', null, ['class' => 'form-control','id'=>'date']); ?>

</div>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $('#date').datetimepicker({
            format: 'YYYY-MM-DD',
            useCurrent: true,
        })

        $('#loan_id').on('change', function () {

            var nextdue = $("#loan_id option:selected").data('nextdue');
            $('#next-due').val(nextdue);

        });

        $('#aux_amount').on('change', function () {

            var pending = $("#loan_id option:selected").data('pending');
            let total = $(this).val();
            let earnings = (2 * pending) / 100;
            let amount = total - earnings;

            $("#activyty_amount").val(amount);
            $("#activyty_earnings").val(earnings);

        });
    </script>
<?php $__env->stopSection(); ?>

<!-- Activity Type Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('activity_type_id', 'Activity Type:'); ?>

    <?php echo Form::select('activity_type_id', $activities, null, ['class' => 'form-control']); ?>

</div>

<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Observation:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('activities.index'); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH /home3/reta110/public_html/tobankgo.tk/tobankgo.tk/resources/views/activities/fields.blade.php ENDPATH**/ ?>