<?php echo e($slot); ?>

<?php /**PATH /home3/reta110/public_html/tobankgo.tk/tobankgo.tk/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>