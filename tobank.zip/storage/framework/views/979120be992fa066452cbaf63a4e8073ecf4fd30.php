 <?php $__env->startSection('content'); ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('advanced')): ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
   Dashboard
   <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
    <!-- Small boxes (Stat box) -->
    <div class="row">
        <div class="col-lg-3 col-xs-12 col-sm-6">
            <!-- small box -->
            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3> <?php echo e($total_saved); ?> </h3>

                    <p>Total saved</p>
                </div>
                <div class="icon">
                    <i class="ion ion-bag"></i>
                </div>
                <a href="#" class="small-box-footer">&nbsp;</a>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-12 col-sm-6">
            <!-- small box -->
            <div class="small-box bg-green">
                <div class="inner">
                    <h3><?php echo e($total_borrowed); ?><sup style="font-size: 20px"></sup></h3>

                    <p>Total borrowed</p>
                </div>
                <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                </div>
                <a href="#" class="small-box-footer">&nbsp;</a>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-12 col-sm-6">
            <!-- small box -->
            <div class="small-box bg-yellow">
                <div class="inner">
                    <h3><?php echo e($user_count); ?></h3>

                    <p>User Registrations</p>
                </div>
                <div class="icon">
                    <i class="ion ion-person-add"></i>
                </div>
                <a href="<?php echo e(route('users.index')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-12 col-sm-6">
            <!-- small box -->
            <div class="small-box bg-red">
                <div class="inner">
                    <h3> <?php echo e($total_loans_count); ?> </h3>

                    <p>Active loans</p>
                </div>
                <div class="icon">
                    <i class="ion ion-android-contract"></i>
                </div>
                <a href="<?php echo e(route('loans.index')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->
        <!-- ./col -->
        <div class="col-lg-3 col-xs-12 col-sm-6">
            <!-- small box -->
            <div class="small-box bg-green">
                <div class="inner">
                    <h3><?php echo e($total_bank_account); ?><sup style="font-size: 20px"></sup></h3>

                    <p>Bank Account</p>
                </div>
                <div class="icon">
                    <i class="ion ion-android-lock"></i>
                </div>
                <a href="#" class="small-box-footer">&nbsp;</a>
            </div>
        </div>
        <!-- ./col -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('advancedActions')): ?>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-12 col-sm-6">
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo e($total_bank_account + $earnings); ?><sup style="font-size: 20px"></sup></h3>

                        <p>Bank Account</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-android-lock"></i>
                    </div>
                    <a href="#" class="small-box-footer">&nbsp;</a>
                </div>
            </div>
            <!-- ./col -->
        <?php endif; ?>
    </div>
    <!-- /.row -->
</section>
<!-- /.content -->
<?php endif; ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
    User information
    <small>Loans Details</small>
  </h1>
</section>

<section class="content">
    <!-- Small boxes (Stat box) -->
    <div class="row">

        <!-- ./col -->
        <div class="col-lg-3 col-xs-12 col-sm-6">
            <!-- small box -->
            <div class="small-box bg-green">
                <div class="inner">
                    <h3> <?php echo e($total_loans); ?> </h3>

                    <p>Total</p>
                </div>
                <div class="icon">
                    <i class="ion ion-cash"></i>
                </div>
                <a href="<?php echo e(route('loans.index')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->

        <div class="col-lg-3 col-xs-12 col-sm-6">
            <!-- small box -->
            <div class="small-box bg-yellow">
                <div class="inner">
                    <h3><?php echo e($remaining); ?></h3>

                    <p>Remaining</p>
                </div>
                <div class="icon">
                    <i class="ion ion-calculator"></i>
                </div>
                <a href="#" class="small-box-footer">&nbsp;</a>
            </div>
        </div>

        <!-- ./col -->
        <div class="col-lg-3 col-xs-12 col-sm-6">
            <!-- small box -->
            <div class="small-box bg-red">
                <div class="inner">
                    <h3><?php echo e($total_user_loans_count); ?><sup style="font-size: 20px"></sup></h3>

                    <p>Active Loans</p>
                </div>
                <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                </div>
                <a href="#" class="small-box-footer">&nbsp;</a>
            </div>
        </div>
        <!-- ./col -->
    </div>
    <!-- /.row -->
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('advanced')): ?>
    <row>
        <div class="box-header">
            <h3 class="box-title">Endorsed loans</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body no-padding">
            <table class="table table-condensed" >
                <tbody><tr>
                    <th style="width: 10px">#</th>
                    <th>user_name</th>
                    <th>amount</th>
                    <th class="hidden-xs">date</th>
                    <th class="hidden-xs">expires_at</th>
                    <th>actions</th>
                </tr>
                <?php
                    $amount = 0;
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $endorses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endorse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($endorse->user->name); ?></td>
                        <td><?php echo e($endorse->amount); ?></td>
                        <td  class="hidden-xs"><?php echo e($endorse->date); ?></td>
                        <td  class="hidden-xs"> <?php echo e($endorse->expires_at); ?></td>
                        <td>
                            <a href="<?php echo e(route('loans.show', $endorse )); ?>" class='btn btn-default btn-xs'>
                                <i class="glyphicon glyphicon-eye-open"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No loans endorse</p>
                <?php endif; ?>
                </tbody></table>

        </div>

    </row>
    <?php endif; ?>
</section>
<!-- /.content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/reta110/public_html/tobankgo.tk/tobankgo.tk/resources/views/dashboard/resume.blade.php ENDPATH**/ ?>