[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home3/reta110/public_html/tobankgo.tk/tobankgo.tk/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>