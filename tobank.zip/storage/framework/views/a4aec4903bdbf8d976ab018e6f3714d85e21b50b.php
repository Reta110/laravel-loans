<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $deposit->id; ?></p>
</div>

<!-- Name Field -->
<div class="form-group">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo $deposit->name; ?></p>
</div>

<!-- Inyection Field -->
<div class="form-group">
    <?php echo Form::label('inyection', 'Inyection:'); ?>

    <p><?php echo $deposit->inyection; ?></p>
</div>

<!-- Amount Field -->
<div class="form-group">
    <?php echo Form::label('amount', 'Amount:'); ?>

    <p><?php echo $deposit->amount; ?></p>
</div>

<!-- User Id Field -->
<div class="form-group">
    <?php echo Form::label('user_id', 'User:'); ?>

    <p><?php echo $deposit->user->name; ?></p>
</div>
<?php /**PATH /home3/reta110/public_html/tobankgo.tk/tobankgo.tk/resources/views/deposits/show_fields.blade.php ENDPATH**/ ?>