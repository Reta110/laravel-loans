<?php $__env->startComponent('mail::message'); ?>
# Login

The user <?php echo e($user->name); ?> has been logged.


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home3/reta110/public_html/tobankgo.tk/tobankgo.tk/resources/views/emails/auth/logged.blade.php ENDPATH**/ ?>