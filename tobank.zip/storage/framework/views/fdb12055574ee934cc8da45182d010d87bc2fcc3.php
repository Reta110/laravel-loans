
<li class="<?php echo e(Request::is('dashboard/resume') ? 'active' : ''); ?>">
    <a href="<?php echo route('dashboard.resume'); ?>"><i class="fa fa-desktop"></i><span>Dashboard</span></a>
</li>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('advanced')): ?>
<li class="<?php echo e(Request::is('dashboard/summary') ? 'active' : ''); ?>">
    <a href="<?php echo route('dashboard.summary'); ?>"><i class="fa fa-bar-chart"></i><span>Monthly Summary (Beta)</span></a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('advancedActions')): ?>
    <li class="treeview <?php echo e(Request::is('dashboard*') ? 'active' : ''); ?>" style="height: auto;">
        <a href="#">
            <i class="fa fa-share"></i> <span>Information</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu" style="display: none;">
            <li>
              <a href="<?php echo route('dashboard.payment'); ?>"><i class="fa fa-balance-scale"></i>Payments</a>
            </li>
            <li><a href="<?php echo route('dashboard.pending_users'); ?>"><i class="fa fa-group"></i>Users Pendings</a></li>
        </ul>
    </li>
<?php endif; ?>

<li class="treeview <?php echo e(Request::is('loans*') ? 'active' : ''); ?>" style="height: auto;">
  <a href="#">
      <i class="fa fa-credit-card"></i> <span>Lonas</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
  </a>
  <ul class="treeview-menu" style="display: none;">
      <li class="<?php echo e(Request::is('loans*') ? 'active' : ''); ?>">
          <a href="<?php echo route('loans.index'); ?>"><i class="fa fa-credit-card"></i><span>Active Loans</span></a>
      </li>
      <li class="<?php echo e(Request::is('loans/history') ? 'active' : ''); ?>">
          <a href="<?php echo route('loans.history'); ?>"><i class="fa fa-credit-card"></i><span>Hisorial</span></a>
      </li>
  </ul>
</li>

<li class="<?php echo e(Request::is('activities*') ? 'active' : ''); ?>">
  <a href="<?php echo route('activities.index'); ?>"><i class="fa fa-tasks"></i><span>Activities</span></a>
</li>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('advanced')): ?>

    <li class="<?php echo e(Request::is('companies*') ? 'active' : ''); ?>">
        <a href="<?php echo route('companies.index'); ?>"><i class="fa fa-bank"></i><span>Companies</span></a>
    </li>

    <li class="<?php echo e(Request::is('users*') ? 'active' : ''); ?>">
        <a href="<?php echo route('users.index'); ?>"><i class="fa fa-user-circle"></i><span>Users</span></a>
    </li>

    <li class="<?php echo e(Request::is('deposits*') ? 'active' : ''); ?>">
        <a href="<?php echo route('deposits.index'); ?>"><i class="fa fa-money"></i><span>Deposits</span></a>
    </li>

    <li class="<?php echo e(Request::is('withdrawals*') ? 'active' : ''); ?>">
        <a href="<?php echo route('withdrawals.index'); ?>"><i class="fa fa-edit"></i><span>Withdrawals</span></a>
    </li>


    <li class="<?php echo e(Request::is('activityTypes*') ? 'active' : ''); ?>">
        <a href="<?php echo route('activityTypes.index'); ?>"><i class="fa fa-file"></i><span>Activity Types</span></a>
    </li>

<?php endif; ?>
<?php /**PATH /home3/reta110/public_html/tobankgo.tk/tobankgo.tk/resources/views/layouts/menu.blade.php ENDPATH**/ ?>