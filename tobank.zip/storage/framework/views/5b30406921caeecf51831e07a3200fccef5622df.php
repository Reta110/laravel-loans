<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $withdrawal->id; ?></p>
</div>

<!-- Name Field -->
<div class="form-group">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo $withdrawal->name; ?></p>
</div>

<!-- Amount Field -->
<div class="form-group">
    <?php echo Form::label('amount', 'Amount:'); ?>

    <p><?php echo $withdrawal->amount; ?></p>
</div>

<!-- User Id Field -->
<div class="form-group">
    <?php echo Form::label('user_id', 'User:'); ?>

    <p><?php echo $withdrawal->user->name; ?></p>
</div>
<?php /**PATH /home3/reta110/public_html/tobankgo.tk/tobankgo.tk/resources/views/withdrawals/show_fields.blade.php ENDPATH**/ ?>