<!-- Id Field -->
<div class="col-md-1 form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $activity->id; ?></p>
</div>

<!-- Amount Field -->
<div class="col-md-2 form-group">
    <?php echo Form::label('amount', 'Amount:'); ?>

    <p><?php echo $activity->amount; ?></p>
</div>

<!-- Earnings Field -->
<div class="col-md-2 form-group">
    <?php echo Form::label('earnings', 'Earnings:'); ?>

    <p><?php echo $activity->earnings; ?></p>
</div>

<!-- Due Field -->
<div class="col-md-1 form-group">
    <?php echo Form::label('due', 'Due:'); ?>

    <p><?php echo $activity->due; ?></p>
</div>

<!-- Date Field -->
<div class="col-md-2 form-group">
    <?php echo Form::label('date', 'Date:'); ?>

    <p><?php echo $activity->date; ?></p>
</div>

<!-- Activity Type Id Field -->
<div class="col-md-2 form-group">
    <?php echo Form::label('activity_type_id', 'Activity Type:'); ?>

    <p><?php echo $activity->activityType->name; ?></p>
</div>

<!-- Name Field -->
<div class="col-md-2 form-group">
    <?php echo Form::label('name', 'Observation:'); ?>

    <p><?php echo $activity->name; ?></p>
</div>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('advanced')): ?>
    <!-- Client Percents Field -->
    <div class="col-md-12 form-group">
        <?php echo Form::label('client_percents', 'Client Percents:'); ?>

        <ul>
            <?php $__currentLoopData = json_decode($activity->client_earnings); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($client->name); ?>: <?php echo e($client->earning_amount); ?> (<?php echo e($client->percent); ?>%)</li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH /home3/reta110/public_html/tobankgo.tk/tobankgo.tk/resources/views/activities/show_fields.blade.php ENDPATH**/ ?>