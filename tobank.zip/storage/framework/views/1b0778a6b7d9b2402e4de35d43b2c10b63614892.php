<?php $__env->startComponent('mail::message'); ?>
# Saludos,

Se ha registrado un depósito a tu nombre, por el monto de: <?php echo e($deposit->amount); ?>


<?php $__env->startComponent('mail::button', ['url' => route('deposits.show', $deposit->id)]); ?>
    Revisar
<?php echo $__env->renderComponent(); ?>

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home3/reta110/public_html/tobankgo.tk/tobankgo.tk/resources/views/emails/deposits/created.blade.php ENDPATH**/ ?>