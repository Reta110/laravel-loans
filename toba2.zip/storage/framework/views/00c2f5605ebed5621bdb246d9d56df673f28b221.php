<?php $__env->startComponent('mail::message'); ?>
# Se creó una actividad

Se ha registrado un <?php echo e($activity->activityType->name); ?>


<?php $__env->startComponent('mail::button', ['url' => route('activities.show', $activity->id)]); ?>
    Revisar
<?php echo $__env->renderComponent(); ?>

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home3/reta110/public_html/tobankgo.tk/tobankgo.tk/resources/views/emails/activities/created.blade.php ENDPATH**/ ?>