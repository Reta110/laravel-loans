<!-- Id Field -->
<div class="form-group  col-sm-3">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $user->id; ?></p>
</div>

<!-- Name Field -->
<div class="form-group  col-sm-3">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo $user->name; ?></p>
</div>

<!-- Email Field -->
<div class="form-group  col-sm-3">
    <?php echo Form::label('email', 'Email:'); ?>

    <p><?php echo $user->email; ?></p>
</div>

<!-- Phone Field -->
<div class="form-group  col-sm-3">
    <?php echo Form::label('phone', 'Phone:'); ?>

    <p><?php echo $user->phone; ?></p>
</div>

<!-- Rut Field -->
<div class="form-group  col-sm-3">
    <?php echo Form::label('rut', 'Rut:'); ?>

    <p><?php echo $user->rut; ?></p>
</div>

<!-- Role Field -->
<div class="form-group  col-sm-3">
    <?php echo Form::label('role', 'Role:'); ?>

    <p><?php echo $user->role; ?></p>
</div>

<!-- Company Id Field -->
<div class="form-group  col-sm-3">
    <?php echo Form::label('company_id', 'Company Id:'); ?>

    <p><?php echo $user->company->name; ?></p>
</div>

<!-- Guarantor Id Field -->
<div class="form-group  col-sm-3">
    <?php echo Form::label('user_id', 'Guarantor:'); ?>

    <p><?php echo $user->guarantor->name; ?></p>
</div>

<!-- Guarantor Id Field -->
<div class="form-group  col-sm-12">
    <?php echo Form::label('observation', 'Observation:'); ?>

    <p><?php echo $user->observation; ?></p>
</div><?php /**PATH /home3/reta110/public_html/tobankgo.tk/tobankgo.tk/resources/views/users/show_fields.blade.php ENDPATH**/ ?>