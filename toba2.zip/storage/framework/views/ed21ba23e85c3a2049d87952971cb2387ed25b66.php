
<!-- Client Field -->
<div class="col-md-2 col-xs-6 form-group">
    <?php echo Form::label('client', 'User:'); ?>

    <p><?php echo $loan->user->name; ?></p>
</div>

<!-- Amount Field -->
<div class="col-md-2 col-xs-6  form-group">
    <?php echo Form::label('amount', 'Amount:'); ?>

    <p><?php echo $loan->amount; ?></p>
</div>

<!-- Percent Field -->
<div class="col-md-1 col-xs-4 form-group">
    <?php echo Form::label('percent', 'Percent:'); ?>

    <p><?php echo $loan->percent; ?></p>
</div>

<!-- Dues Field -->
<div class="col-md-1 col-xs-4  form-group">
    <?php echo Form::label('dues', 'Dues:'); ?>

    <p><?php echo $loan->dues; ?></p>
</div>

<!-- Finished Field -->
<div class="col-md-2 col-xs-4  form-group">
    <?php echo Form::label('finished', 'Finished:'); ?>

    <p><?php echo $loan->finished; ?></p>
</div>

<!-- Expires At Field -->
<div class="col-md-2  col-xs-6 form-group">
    <?php echo Form::label('expires_at', 'Expires At:'); ?>

    <p><?php echo $loan->expires_at; ?></p>
</div>

<!-- User Id Field -->
<div class="col-md-2 col-xs-6  form-group">
    <?php echo Form::label('user_id', 'User who endorses:'); ?>

    <p><?php echo $loan->client->name; ?></p>
</div>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('advanced')): ?>
    <!-- Client Percents Field -->
    <div class="form-group">
        <?php echo Form::label('client_percents', 'Client Percents:'); ?>

        <ul>
            <?php $__currentLoopData = json_decode($loan->client_percents); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($client->name); ?> - <?php echo e($client->percent); ?>%</li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<section class="content">
      <div class="row">
        <div class="col-md-12">
<div class="box">
      <div class="box-header">
        <h3 class="box-title">Actividades</h3>
      </div>
      <!-- /.box-header -->
      <div class="box-body no-padding">
        <table class="table table-condensed" >
          <tbody><tr>
            <th style="width: 10px">#</th>
            <th>Task</th>
            <th>Date</th>
            <th>Amount</th>
            <th>Interest</th>
            <th>Progress</th>
            <th style="width: 40px">Label</th>
          </tr>
          <?php
            $amount = 0;
          ?>
          <?php $__empty_1 = true; $__currentLoopData = $loan->activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($loop->iteration); ?></td>
              <td>
                <a href="<?php echo e(route('activities.show', $activity )); ?>"><?php echo e($activity->activityType->name); ?></a>
              </td>
              <td><?php echo e($activity->date); ?></td>
              <td><?php echo e($activity->amount); ?></td>
              <td><?php echo e($activity->earnings); ?></td>
              <td>
                <?php
                  $amount += $activity->amount;
                ?>
                <div class="progress progress-xs">
                  <div class="progress-bar progress-bar-success" style="width: <?php echo e(round(($amount * 100) / $loan->amount)); ?>%"></div>
                </div>
              </td>
              <td><span class="badge bg-success"><?php echo e(round(($amount * 100) / $loan->amount)); ?>%</span></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <p>No activities</p>
          <?php endif; ?>
        </tbody></table>

      </div>



    <!-- /.box-body -->
    </div>
        <div class="col-md-2 col-xs-6 form-group ">
            <p>Total Pending: <?php echo e($loan->amount - $amount); ?></p>
            <p>Next interest to pay: <?php echo e(round((($loan->amount - $amount) *  $loan->percent) / 100, 2)); ?></p>
        </div>

    </div>
    </div>
    </div>
<?php /**PATH /home3/reta110/public_html/tobankgo.tk/tobankgo.tk/resources/views/loans/show_fields.blade.php ENDPATH**/ ?>