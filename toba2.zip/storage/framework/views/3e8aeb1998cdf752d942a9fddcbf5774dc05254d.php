<!-- Client Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('user_id', 'User:'); ?>

    <?php echo Form::select('user_id', $users, null, ['class' => 'form-control']); ?>

</div>

<!-- Amount Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('amount', 'Amount:'); ?>

    <?php echo Form::number('amount', null, ['class' => 'form-control']); ?>

</div>

<!-- Percent Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('percent', 'Percent:'); ?>

    <?php echo Form::number('percent', 2, ['class' => 'form-control']); ?>

</div>

<!-- Dues Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('dues', 'Dues:'); ?>

    <?php echo Form::number('dues', 6, ['class' => 'form-control']); ?>

</div>

<!-- date -->
<div class="form-group col-sm-6">
    <?php echo Form::label('date', 'Date:'); ?>

    <?php echo Form::date('date', null, ['class' => 'form-control','id'=>'date']); ?>

</div>

<!-- Expires At Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('expires_at', 'Expires At:'); ?>

    <?php echo Form::date('expires_at', null, ['class' => 'form-control','id'=>'expires_at']); ?>

</div>

<!-- User Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('client_id', 'Client who endorses:'); ?>

    <?php echo Form::select('client_id', $clients, null, ['class' => 'form-control']); ?>

</div>

<!-- Observation Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('observation', 'Observation:'); ?>

    <?php echo Form::text('observation', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('loans.index'); ?>" class="btn btn-default">Cancel</a>
</div>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $('#date').datetimepicker({
            format: 'YYYY-MM-DD',
            useCurrent: true
        })
    </script>

    <script type="text/javascript">
        $('#expires_at').datetimepicker({
            format: 'YYYY-MM-DD',
            useCurrent: true
        })
    </script>
<?php $__env->stopSection(); ?> 
<?php /**PATH /home3/reta110/public_html/tobankgo.tk/tobankgo.tk/resources/views/loans/fields.blade.php ENDPATH**/ ?>