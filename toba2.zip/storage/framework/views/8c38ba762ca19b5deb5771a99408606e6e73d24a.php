
<!-- Amount Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('amount', 'Amount:'); ?>

    <?php echo Form::number('amount', null, ['class' => 'form-control']); ?>

</div>

<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Observation:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- User Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('user_id', 'User:'); ?>

    <?php echo Form::select('user_id', $users, null, ['class' => 'form-control']); ?>

</div>

<!-- Date Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('date', 'Date:'); ?>

    <?php echo Form::date('date', null, ['class' => 'form-control','id'=>'date']); ?>

</div>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $('#date').datetimepicker({
            format: 'YYYY-MM-DD',
            useCurrent: true
        })
    </script>
<?php $__env->stopSection(); ?>


<!-- Inyection Field -->
<div class="form-group col-sm-12">
    <label class="checkbox-inline">
        <?php echo Form::hidden('inyection', 0); ?>

        <?php echo Form::checkbox('inyection', '1', 0); ?> Inyection
    </label>
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('deposits.index'); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH /home3/reta110/public_html/tobankgo.tk/tobankgo.tk/resources/views/deposits/fields.blade.php ENDPATH**/ ?>