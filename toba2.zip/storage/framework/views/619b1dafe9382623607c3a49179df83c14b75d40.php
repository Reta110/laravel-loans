<?php echo Form::open(['route' => ['loans.destroy', $id], 'method' => 'delete']); ?>

<div class='btn-group'>
    <a href="<?php echo e(route('loans.show', $id)); ?>" class='btn btn-default btn-xs'>
        <i class="glyphicon glyphicon-eye-open"></i>
    </a>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('advancedActions')): ?>
      <a href="<?php echo e(route('loans.edit', $id)); ?>" class='btn btn-default btn-xs'>
          <i class="glyphicon glyphicon-edit"></i>
      </a>
      <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', [
          'type' => 'submit',
          'class' => 'btn btn-danger btn-xs',
          'onclick' => "return confirm('Are you sure?')"
      ]); ?>

    <?php endif; ?>
</div>
<?php echo Form::close(); ?>

<?php /**PATH /home3/reta110/public_html/tobankgo.tk/tobankgo.tk/resources/views/loans/datatables_actions.blade.php ENDPATH**/ ?>