<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Email Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('email', 'Email:'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

</div>

<!-- Phone Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('phone', 'Phone:'); ?>

    <?php echo Form::text('phone', null, ['class' => 'form-control']); ?>

</div>

<!-- Rut Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('rut', 'Rut:'); ?>

    <?php echo Form::text('rut', null, ['class' => 'form-control']); ?>

</div>

<!-- Role Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('role', 'Role:'); ?>

    <?php echo Form::select('role', ['client' => 'Client', 'user' => 'User'], null, ['class' => 'form-control']); ?>

</div>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $('#email_verified_at').datetimepicker({
        format: 'YYYY-MM-DD HH:mm:ss',
        useCurrent: false
    })
</script>
<?php $__env->stopSection(); ?>

<!-- Password Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('password', 'Password:'); ?>

    <?php echo Form::password('password', ['class' => 'form-control']); ?>

</div>

<!-- Company Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('company_id', 'Company:'); ?>

    <?php echo Form::select('company_id', $companies, null, ['class' => 'form-control']); ?>

</div>

<!-- Company Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('user_id', 'Aval:'); ?>

    <?php echo Form::select('user_id', $users, null, ['class' => 'form-control']); ?>

</div>

<!-- Observation Id Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('observation', 'Observation:'); ?>

    <?php echo Form::text('observation', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('users.index'); ?>" class="btn btn-default">Cancel</a>
</div><?php /**PATH /home3/reta110/public_html/tobankgo.tk/tobankgo.tk/resources/views/users/fields.blade.php ENDPATH**/ ?>