
<li class="{{ Request::is('dashboard/resume') ? 'active' : '' }}">
    <a href="{!! route('dashboard.resume') !!}"><i class="fa fa-desktop"></i><span>Dashboard</span></a>
</li>

@can('advanced')
<li class="{{ Request::is('dashboard/summary') ? 'active' : '' }}">
    <a href="{!! route('dashboard.summary') !!}"><i class="fa fa-bar-chart"></i><span>Monthly Summary (Beta)</span></a>
</li>
@endcan

@can('advancedActions')
    <li class="treeview {{ Request::is('dashboard*') ? 'active' : '' }}" style="height: auto;">
        <a href="#">
            <i class="fa fa-share"></i> <span>Information</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu" style="display: none;">
            <li>
              <a href="{!! route('dashboard.payment') !!}"><i class="fa fa-balance-scale"></i>Payments</a>
            </li>
            <li><a href="{!! route('dashboard.pending_users') !!}"><i class="fa fa-group"></i>Users Pendings</a></li>
        </ul>
    </li>
@endcan

<li class="treeview {{ Request::is('loans*') ? 'active' : '' }}" style="height: auto;">
  <a href="#">
      <i class="fa fa-credit-card"></i> <span>Lonas</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
  </a>
  <ul class="treeview-menu" style="display: none;">
      <li class="{{ Request::is('loans*') ? 'active' : '' }}">
          <a href="{!! route('loans.index') !!}"><i class="fa fa-credit-card"></i><span>Active Loans</span></a>
      </li>
      <li class="{{ Request::is('loans/history') ? 'active' : '' }}">
          <a href="{!! route('loans.history') !!}"><i class="fa fa-credit-card"></i><span>Hisorial</span></a>
      </li>
  </ul>
</li>

<li class="{{ Request::is('activities*') ? 'active' : '' }}">
  <a href="{!! route('activities.index') !!}"><i class="fa fa-tasks"></i><span>Activities</span></a>
</li>

@can('advanced')

    <li class="{{ Request::is('companies*') ? 'active' : '' }}">
        <a href="{!! route('companies.index') !!}"><i class="fa fa-bank"></i><span>Companies</span></a>
    </li>

    <li class="{{ Request::is('users*') ? 'active' : '' }}">
        <a href="{!! route('users.index') !!}"><i class="fa fa-user-circle"></i><span>Users</span></a>
    </li>

    <li class="{{ Request::is('deposits*') ? 'active' : '' }}">
        <a href="{!! route('deposits.index') !!}"><i class="fa fa-money"></i><span>Deposits</span></a>
    </li>

    <li class="{{ Request::is('withdrawals*') ? 'active' : '' }}">
        <a href="{!! route('withdrawals.index') !!}"><i class="fa fa-edit"></i><span>Withdrawals</span></a>
    </li>


    <li class="{{ Request::is('activityTypes*') ? 'active' : '' }}">
        <a href="{!! route('activityTypes.index') !!}"><i class="fa fa-file"></i><span>Activity Types</span></a>
    </li>

@endcan
