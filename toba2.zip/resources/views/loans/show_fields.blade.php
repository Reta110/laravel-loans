
<!-- Client Field -->
<div class="col-md-2 col-xs-6 form-group">
    {!! Form::label('client', 'User:') !!}
    <p>{!! $loan->user->name !!}</p>
</div>

<!-- Amount Field -->
<div class="col-md-2 col-xs-6  form-group">
    {!! Form::label('amount', 'Amount:') !!}
    <p>{!! $loan->amount !!}</p>
</div>

<!-- Percent Field -->
<div class="col-md-1 col-xs-4 form-group">
    {!! Form::label('percent', 'Percent:') !!}
    <p>{!! $loan->percent !!}</p>
</div>

<!-- Dues Field -->
<div class="col-md-1 col-xs-4  form-group">
    {!! Form::label('dues', 'Dues:') !!}
    <p>{!! $loan->dues !!}</p>
</div>

<!-- Finished Field -->
<div class="col-md-2 col-xs-4  form-group">
    {!! Form::label('finished', 'Finished:') !!}
    <p>{!! $loan->finished !!}</p>
</div>

<!-- Expires At Field -->
<div class="col-md-2  col-xs-6 form-group">
    {!! Form::label('expires_at', 'Expires At:') !!}
    <p>{!! $loan->expires_at !!}</p>
</div>

<!-- User Id Field -->
<div class="col-md-2 col-xs-6  form-group">
    {!! Form::label('user_id', 'User who endorses:') !!}
    <p>{!! $loan->client->name !!}</p>
</div>

@can('advanced')
    <!-- Client Percents Field -->
    <div class="form-group">
        {!! Form::label('client_percents', 'Client Percents:') !!}
        <ul>
            @foreach(json_decode($loan->client_percents) as $client)
                <li>{{ $client->name }} - {{ $client->percent }}%</li>
            @endforeach
        </ul>
    </div>
@endcan

<section class="content">
      <div class="row">
        <div class="col-md-12">
<div class="box">
      <div class="box-header">
        <h3 class="box-title">Actividades</h3>
      </div>
      <!-- /.box-header -->
      <div class="box-body no-padding">
        <table class="table table-condensed" >
          <tbody><tr>
            <th style="width: 10px">#</th>
            <th>Task</th>
            <th>Date</th>
            <th>Amount</th>
            <th>Interest</th>
            <th>Progress</th>
            <th style="width: 40px">Label</th>
          </tr>
          @php
            $amount = 0;
          @endphp
          @forelse($loan->activities as $activity)
            <tr>
              <td>{{$loop->iteration}}</td>
              <td>
                <a href="{{route('activities.show', $activity )}}">{{ $activity->activityType->name }}</a>
              </td>
              <td>{{ $activity->date }}</td>
              <td>{{ $activity->amount }}</td>
              <td>{{ $activity->earnings }}</td>
              <td>
                @php
                  $amount += $activity->amount;
                @endphp
                <div class="progress progress-xs">
                  <div class="progress-bar progress-bar-success" style="width: {{ round(($amount * 100) / $loan->amount)}}%"></div>
                </div>
              </td>
              <td><span class="badge bg-success">{{ round(($amount * 100) / $loan->amount)}}%</span></td>
            </tr>
          @empty
              <p>No activities</p>
          @endforelse
        </tbody></table>

      </div>



    <!-- /.box-body -->
    </div>
        <div class="col-md-2 col-xs-6 form-group ">
            <p>Total Pending: {{ $loan->amount - $amount }}</p>
            <p>Next interest to pay: {{ round((($loan->amount - $amount) *  $loan->percent) / 100, 2) }}</p>
        </div>

    </div>
    </div>
    </div>
