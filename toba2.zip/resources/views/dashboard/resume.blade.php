@extends('layouts.app') @section('content') @can('advanced')
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
   Dashboard
   <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
    <!-- Small boxes (Stat box) -->
    <div class="row">
        <div class="col-lg-3 col-xs-12 col-sm-6">
            <!-- small box -->
            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3> {{ $total_saved }} </h3>

                    <p>Total saved</p>
                </div>
                <div class="icon">
                    <i class="ion ion-bag"></i>
                </div>
                <a href="#" class="small-box-footer">&nbsp;</a>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-12 col-sm-6">
            <!-- small box -->
            <div class="small-box bg-green">
                <div class="inner">
                    <h3>{{ $total_borrowed }}<sup style="font-size: 20px"></sup></h3>

                    <p>Total borrowed</p>
                </div>
                <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                </div>
                <a href="#" class="small-box-footer">&nbsp;</a>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-12 col-sm-6">
            <!-- small box -->
            <div class="small-box bg-yellow">
                <div class="inner">
                    <h3>{{ $user_count }}</h3>

                    <p>User Registrations</p>
                </div>
                <div class="icon">
                    <i class="ion ion-person-add"></i>
                </div>
                <a href="{{ route('users.index') }}" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-12 col-sm-6">
            <!-- small box -->
            <div class="small-box bg-red">
                <div class="inner">
                    <h3> {{ $total_loans_count }} </h3>

                    <p>Active loans</p>
                </div>
                <div class="icon">
                    <i class="ion ion-android-contract"></i>
                </div>
                <a href="{{ route('loans.index') }}" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->
        <!-- ./col -->
        <div class="col-lg-3 col-xs-12 col-sm-6">
            <!-- small box -->
            <div class="small-box bg-green">
                <div class="inner">
                    <h3>{{ $total_bank_account }}<sup style="font-size: 20px"></sup></h3>

                    <p>Bank Account</p>
                </div>
                <div class="icon">
                    <i class="ion ion-android-lock"></i>
                </div>
                <a href="#" class="small-box-footer">&nbsp;</a>
            </div>
        </div>
        <!-- ./col -->
        @can('advancedActions')
            <!-- ./col -->
            <div class="col-lg-3 col-xs-12 col-sm-6">
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3>{{ $total_bank_account + $earnings }}<sup style="font-size: 20px"></sup></h3>

                        <p>Bank Account</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-android-lock"></i>
                    </div>
                    <a href="#" class="small-box-footer">&nbsp;</a>
                </div>
            </div>
            <!-- ./col -->
        @endcan
    </div>
    <!-- /.row -->
</section>
<!-- /.content -->
@endcan

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
    User information
    <small>Loans Details</small>
  </h1>
</section>

<section class="content">
    <!-- Small boxes (Stat box) -->
    <div class="row">

        <!-- ./col -->
        <div class="col-lg-3 col-xs-12 col-sm-6">
            <!-- small box -->
            <div class="small-box bg-green">
                <div class="inner">
                    <h3> {{ $total_loans }} </h3>

                    <p>Total</p>
                </div>
                <div class="icon">
                    <i class="ion ion-cash"></i>
                </div>
                <a href="{{ route('loans.index') }}" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->

        <div class="col-lg-3 col-xs-12 col-sm-6">
            <!-- small box -->
            <div class="small-box bg-yellow">
                <div class="inner">
                    <h3>{{ $remaining }}</h3>

                    <p>Remaining</p>
                </div>
                <div class="icon">
                    <i class="ion ion-calculator"></i>
                </div>
                <a href="#" class="small-box-footer">&nbsp;</a>
            </div>
        </div>

        <!-- ./col -->
        <div class="col-lg-3 col-xs-12 col-sm-6">
            <!-- small box -->
            <div class="small-box bg-red">
                <div class="inner">
                    <h3>{{ $total_user_loans_count }}<sup style="font-size: 20px"></sup></h3>

                    <p>Active Loans</p>
                </div>
                <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                </div>
                <a href="#" class="small-box-footer">&nbsp;</a>
            </div>
        </div>
        <!-- ./col -->
    </div>
    <!-- /.row -->
    @can('advanced')
    <row>
        <div class="box-header">
            <h3 class="box-title">Endorsed loans</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body no-padding">
            <table class="table table-condensed" >
                <tbody><tr>
                    <th style="width: 10px">#</th>
                    <th>user_name</th>
                    <th>amount</th>
                    <th class="hidden-xs">date</th>
                    <th class="hidden-xs">expires_at</th>
                    <th>actions</th>
                </tr>
                @php
                    $amount = 0;
                @endphp
                @forelse($endorses as $endorse)
                    <tr>
                        <td>{{$loop->iteration}}</td>
                        <td>{{ $endorse->user->name }}</td>
                        <td>{{ $endorse->amount }}</td>
                        <td  class="hidden-xs">{{ $endorse->date }}</td>
                        <td  class="hidden-xs"> {{ $endorse->expires_at }}</td>
                        <td>
                            <a href="{{route('loans.show', $endorse )}}" class='btn btn-default btn-xs'>
                                <i class="glyphicon glyphicon-eye-open"></i>
                            </a>
                        </td>
                    </tr>
                @empty
                    <p>No loans endorse</p>
                @endforelse
                </tbody></table>

        </div>

    </row>
    @endcan
</section>
<!-- /.content -->

@endsection
